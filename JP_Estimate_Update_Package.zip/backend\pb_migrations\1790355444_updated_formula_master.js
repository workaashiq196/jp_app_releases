/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  let collection
  try {
    collection = app.findCollectionByNameOrId("formula_master_col")
  } catch (e) {
    try {
      collection = app.findCollectionByNameOrId("formula_master")
    } catch (e2) {
      collection = new Collection({
        "id": "formula_master_col",
        "name": "formula_master",
        "type": "base",
        "system": false,
      })
    }
  }

  // update collection data
  unmarshal({
    "createRule": "",
    "deleteRule": "",
    "listRule": "",
    "updateRule": "",
    "viewRule": ""
  }, collection)

  return app.save(collection)
}, (app) => {
  let collection
  try {
    collection = app.findCollectionByNameOrId("formula_master_col")
  } catch (e) {
    try {
      collection = app.findCollectionByNameOrId("formula_master")
    } catch (e2) {
      return
    }
  }

  // update collection data
  unmarshal({
    "createRule": "@request.auth.role = 'MD' || @request.auth.role = 'Manager'",
    "deleteRule": "@request.auth.role = 'MD'",
    "listRule": "@request.auth.id != ''",
    "updateRule": "@request.auth.role = 'MD' || @request.auth.role = 'Manager'",
    "viewRule": "@request.auth.id != ''"
  }, collection)

  return app.save(collection)
})
