/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  // update collection data
  unmarshal({
    "createRule": "",
    "deleteRule": "",
    "listRule": "",
    "updateRule": "",
    "viewRule": ""
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  // update collection data
  unmarshal({
    "createRule": "@request.auth.id != ''",
    "deleteRule": "@request.auth.role = 'MD'",
    "listRule": "@request.auth.id != ''",
    "updateRule": "@request.auth.role = 'MD' || @request.auth.role = 'Manager'",
    "viewRule": "@request.auth.id != ''"
  }, collection)

  return app.save(collection)
})
