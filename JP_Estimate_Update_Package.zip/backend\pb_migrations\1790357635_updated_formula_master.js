/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  let collection
  try {
    collection = app.findCollectionByNameOrId("formula_master_col")
  } catch (e) {
    try {
      collection = app.findCollectionByNameOrId("formula_master")
    } catch (e2) {
      collection = new Collection({
        "id": "formula_master_col",
        "name": "formula_master",
        "type": "base",
        "system": false,
      })
    }
  }

  // add field if not exists
  if (!collection.fields.getByName("micron_label")) {
    collection.fields.addAt(1, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text3844853612",
      "max": 0,
      "min": 0,
      "name": "micron_label",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": true,
      "system": false,
      "type": "text"
    }))
  }

  // add field if not exists
  if (!collection.fields.getByName("multiplier")) {
    collection.fields.addAt(2, new Field({
      "help": "",
      "hidden": false,
      "id": "number2761599323",
      "max": null,
      "min": null,
      "name": "multiplier",
      "onlyInt": false,
      "presentable": false,
      "required": true,
      "system": false,
      "type": "number"
    }))
  }

  // add field if not exists
  if (!collection.fields.getByName("divisor_factor")) {
    collection.fields.addAt(3, new Field({
      "help": "",
      "hidden": false,
      "id": "number3572766484",
      "max": null,
      "min": null,
      "name": "divisor_factor",
      "onlyInt": false,
      "presentable": false,
      "required": false,
      "system": false,
      "type": "number"
    }))
  }

  return app.save(collection)
}, (app) => {
  let collection
  try {
    collection = app.findCollectionByNameOrId("formula_master_col")
  } catch (e) {
    try {
      collection = app.findCollectionByNameOrId("formula_master")
    } catch (e2) {
      return
    }
  }

  // remove field
  collection.fields.removeById("text3844853612")

  // remove field
  collection.fields.removeById("number2761599323")

  // remove field
  collection.fields.removeById("number3572766484")

  return app.save(collection)
})
