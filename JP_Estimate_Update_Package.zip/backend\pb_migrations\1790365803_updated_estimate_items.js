/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimate_items_col")

  // add field
  collection.fields.addAt(11, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text2034529465",
    "max": 0,
    "min": 0,
    "name": "brand_name",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(12, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text3916701216",
    "max": 0,
    "min": 0,
    "name": "pouch_name",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(13, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text3784763899",
    "max": 0,
    "min": 0,
    "name": "inch_size",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(14, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text20346248",
    "max": 0,
    "min": 0,
    "name": "product_type",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(15, new Field({
    "help": "",
    "hidden": false,
    "id": "number834477364",
    "max": null,
    "min": null,
    "name": "per_kg_pcs",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimate_items_col")

  // remove field
  collection.fields.removeById("text2034529465")

  // remove field
  collection.fields.removeById("text3916701216")

  // remove field
  collection.fields.removeById("text3784763899")

  // remove field
  collection.fields.removeById("text20346248")

  // remove field
  collection.fields.removeById("number834477364")

  return app.save(collection)
})
