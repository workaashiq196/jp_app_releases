/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimate_items_col")

  // add field
  collection.fields.addAt(16, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text1769871750",
    "max": 0,
    "min": 0,
    "name": "pouch_type_id",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(17, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text453814001",
    "max": 0,
    "min": 0,
    "name": "unit_mode",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(18, new Field({
    "help": "",
    "hidden": false,
    "id": "json2665941137",
    "maxSize": 0,
    "name": "width_segments",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "json"
  }))

  // add field
  collection.fields.addAt(19, new Field({
    "help": "",
    "hidden": false,
    "id": "json2080695950",
    "maxSize": 0,
    "name": "height_segments",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "json"
  }))

  // add field
  collection.fields.addAt(20, new Field({
    "help": "",
    "hidden": false,
    "id": "number1555243479",
    "max": null,
    "min": null,
    "name": "seal_w",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(21, new Field({
    "help": "",
    "hidden": false,
    "id": "number3518704674",
    "max": null,
    "min": null,
    "name": "seal_h",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimate_items_col")

  // remove field
  collection.fields.removeById("text1769871750")

  // remove field
  collection.fields.removeById("text453814001")

  // remove field
  collection.fields.removeById("json2665941137")

  // remove field
  collection.fields.removeById("json2080695950")

  // remove field
  collection.fields.removeById("number1555243479")

  // remove field
  collection.fields.removeById("number3518704674")

  return app.save(collection)
})
