/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("company_settings_col")

  // add field
  collection.fields.addAt(12, new Field({
    "help": "",
    "hidden": false,
    "id": "number4097114485",
    "max": null,
    "min": null,
    "name": "min_cylinder_rate",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(13, new Field({
    "help": "",
    "hidden": false,
    "id": "number4122374678",
    "max": null,
    "min": null,
    "name": "min_stereo_rate",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("company_settings_col")

  // remove field
  collection.fields.removeById("number4097114485")

  // remove field
  collection.fields.removeById("number4122374678")

  return app.save(collection)
})
