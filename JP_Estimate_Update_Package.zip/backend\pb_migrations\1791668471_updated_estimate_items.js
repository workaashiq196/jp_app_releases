/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimate_items_col")

  // add field
  collection.fields.addAt(22, new Field({
    "hidden": false,
    "id": "autodate9185600277",
    "name": "created",
    "onCreate": true,
    "onUpdate": false,
    "presentable": false,
    "system": false,
    "type": "autodate"
  }))

  // add field
  collection.fields.addAt(23, new Field({
    "hidden": false,
    "id": "autodate6992110482",
    "name": "updated",
    "onCreate": true,
    "onUpdate": true,
    "presentable": false,
    "system": false,
    "type": "autodate"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimate_items_col")

  // remove field
  collection.fields.removeById("autodate9185600277")

  // remove field
  collection.fields.removeById("autodate6992110482")

  return app.save(collection)
})
