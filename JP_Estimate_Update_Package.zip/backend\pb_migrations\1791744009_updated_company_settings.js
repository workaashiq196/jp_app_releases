/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("company_settings_col")

  // add field
  collection.fields.addAt(14, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text3079228586",
    "max": 0,
    "min": 0,
    "name": "companyName",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(15, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text1958055420",
    "max": 0,
    "min": 0,
    "name": "gstNo",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(16, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text3647216044",
    "max": 0,
    "min": 0,
    "name": "bankName",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(17, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text3125673127",
    "max": 0,
    "min": 0,
    "name": "accountNo",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(18, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text3886493550",
    "max": 0,
    "min": 0,
    "name": "ifscCode",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(19, new Field({
    "help": "",
    "hidden": false,
    "id": "number647237414",
    "max": null,
    "min": null,
    "name": "startingEstimateNo",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(20, new Field({
    "help": "",
    "hidden": false,
    "id": "number2978730602",
    "max": null,
    "min": null,
    "name": "cylinderMinRate",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(21, new Field({
    "help": "",
    "hidden": false,
    "id": "number2444835196",
    "max": null,
    "min": null,
    "name": "stereoMinRate",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(22, new Field({
    "autogeneratePattern": "",
    "help": "",
    "hidden": false,
    "id": "text2452873603",
    "max": 0,
    "min": 0,
    "name": "pdfSavePath",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("company_settings_col")

  // remove field
  collection.fields.removeById("text3079228586")

  // remove field
  collection.fields.removeById("text1958055420")

  // remove field
  collection.fields.removeById("text3647216044")

  // remove field
  collection.fields.removeById("text3125673127")

  // remove field
  collection.fields.removeById("text3886493550")

  // remove field
  collection.fields.removeById("number647237414")

  // remove field
  collection.fields.removeById("number2978730602")

  // remove field
  collection.fields.removeById("number2444835196")

  // remove field
  collection.fields.removeById("text2452873603")

  return app.save(collection)
})
