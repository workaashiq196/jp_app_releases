/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("clients_col")

  if (!collection.fields.getByName("has_separate_delivery_address")) {
    // add has_separate_delivery_address
    collection.fields.addAt(5, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "bool3141592653",
      "name": "has_separate_delivery_address",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "bool"
    }))
  }

  if (!collection.fields.getByName("delivery_name")) {
    // add delivery_name
    collection.fields.addAt(6, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text3141592654",
      "max": 0,
      "min": 0,
      "name": "delivery_name",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  if (!collection.fields.getByName("delivery_address")) {
    // add delivery_address
    collection.fields.addAt(7, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text3141592655",
      "max": 0,
      "min": 0,
      "name": "delivery_address",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  if (!collection.fields.getByName("delivery_pincode")) {
    // add delivery_pincode
    collection.fields.addAt(8, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text3141592656",
      "max": 0,
      "min": 0,
      "name": "delivery_pincode",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  if (!collection.fields.getByName("delivery_phone")) {
    // add delivery_phone
    collection.fields.addAt(9, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text3141592657",
      "max": 0,
      "min": 0,
      "name": "delivery_phone",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("clients_col")

  collection.fields.removeById("bool3141592653")
  collection.fields.removeById("text3141592654")
  collection.fields.removeById("text3141592655")
  collection.fields.removeById("text3141592656")
  collection.fields.removeById("text3141592657")

  return app.save(collection)
})
