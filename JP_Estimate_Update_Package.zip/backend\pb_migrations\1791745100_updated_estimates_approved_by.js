/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  if (!collection.fields.getByName("approved_by")) {
    // add approved_by
    collection.fields.addAt(13, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text_approved_by",
      "max": 0,
      "min": 0,
      "name": "approved_by",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  collection.fields.removeById("text_approved_by")

  return app.save(collection)
})
