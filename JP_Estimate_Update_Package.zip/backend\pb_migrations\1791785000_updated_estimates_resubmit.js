/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  if (!collection.fields.getByName("rejection_note")) {
    // add rejection_note
    collection.fields.addAt(16, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text_rejection_note",
      "max": 0,
      "min": 0,
      "name": "rejection_note",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  if (!collection.fields.getByName("resubmitted_at")) {
    // add resubmitted_at
    collection.fields.addAt(17, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text_resubmitted_at",
      "max": 0,
      "min": 0,
      "name": "resubmitted_at",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  collection.fields.removeById("text_rejection_note")
  collection.fields.removeById("text_resubmitted_at")

  return app.save(collection)
})
