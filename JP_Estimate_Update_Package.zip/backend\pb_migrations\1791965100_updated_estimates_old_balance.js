/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  if (!collection.fields.getByName("old_balance")) {
    collection.fields.addAt(collection.fields.length, new Field({
      "help": "",
      "hidden": false,
      "id": "number_old_balance",
      "max": null,
      "min": null,
      "name": "old_balance",
      "onlyInt": false,
      "presentable": false,
      "required": false,
      "system": false,
      "type": "number"
    }))
  }

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  collection.fields.removeById("number_old_balance")

  return app.save(collection)
})
