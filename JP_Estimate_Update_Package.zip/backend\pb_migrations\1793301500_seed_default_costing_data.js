/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const defaultRawMaterials = [
    { mtlcde: 1, mtlnme: "FILM", mtlrt: 185.00, mtldt: "15/09/2026", boprt: 0.00 },
    { mtlcde: 2, mtlnme: "LD", mtlrt: 180.00, mtldt: "15/09/2026", boprt: 0.00 },
    { mtlcde: 3, mtlnme: "INK", mtlrt: 350.00, mtldt: "26/06/2026", boprt: 0.00 },
    { mtlcde: 4, mtlnme: "SOLVENT (PTG)", mtlrt: 140.00, mtldt: "13/04/2026", boprt: 0.00 },
    { mtlcde: 5, mtlnme: "GUM", mtlrt: 265.00, mtldt: "13/04/2025", boprt: 0.00 },
    { mtlcde: 6, mtlnme: "SOLVENT (LAM)", mtlrt: 112.00, mtldt: "11/08/2026", boprt: 0.00 },
    { mtlcde: 7, mtlnme: "PROD.COST-1", mtlrt: 75.00, mtldt: "11/08/2026", boprt: 0.00 },
    { mtlcde: 8, mtlnme: "WASTE", mtlrt: 10.00, mtldt: "26/06/2026", boprt: 0.00 },
    { mtlcde: 9, mtlnme: "GST", mtlrt: 18.00, mtldt: "11/04/2026", boprt: 0.00 },
    { mtlcde: 10, mtlnme: "FILM [SILVER]", mtlrt: 205.00, mtldt: "15/09/2026", boprt: 0.00 },
    { mtlcde: 11, mtlnme: "WINDOW INK", mtlrt: 0.00, mtldt: "11/04/2026", boprt: 0.00 },
    { mtlcde: 12, mtlnme: "SILVER WINDOW", mtlrt: 100.00, mtldt: "11/04/2026", boprt: 0.00 },
    { mtlcde: 13, mtlnme: "BOPP", mtlrt: 180.00, mtldt: "31/07/2026", boprt: 0.00 },
    { mtlcde: 14, mtlnme: "PROD.COST-2", mtlrt: 50.00, mtldt: "31/07/2026", boprt: 0.00 },
    { mtlcde: 15, mtlnme: "NYLON", mtlrt: 330.00, mtldt: "11/04/2026", boprt: 0.00 },
    { mtlcde: 16, mtlnme: "FILM(BOARD)", mtlrt: 340.00, mtldt: "11/04/2026", boprt: 0.00 },
    { mtlcde: 17, mtlnme: "BOARD", mtlrt: 40.00, mtldt: "11/04/2026", boprt: 0.00 }
  ];

  // 1. Seed raw_materials if empty or missing codes
  try {
    const rawCol = app.findCollectionByNameOrId("raw_materials");
    for (const item of defaultRawMaterials) {
      try {
        const existing = app.findFirstRecordByFilter("raw_materials", "mtlcde = {:cde}", { cde: item.mtlcde });
        if (!existing) {
          const rec = new Record(rawCol);
          rec.set("mtlcde", item.mtlcde);
          rec.set("mtlnme", item.mtlnme);
          rec.set("mtlrt", item.mtlrt);
          rec.set("mtldt", item.mtldt);
          rec.set("boprt", item.boprt);
          app.save(rec);
        }
      } catch (_) {
        const rec = new Record(rawCol);
        rec.set("mtlcde", item.mtlcde);
        rec.set("mtlnme", item.mtlnme);
        rec.set("mtlrt", item.mtlrt);
        rec.set("mtldt", item.mtldt);
        rec.set("boprt", item.boprt);
        app.save(rec);
      }
    }
  } catch (e) {
    console.log("Migration notice for raw_materials: " + e);
  }

  // 2. Seed costing_settings if empty
  try {
    const settingsCol = app.findCollectionByNameOrId("costing_settings");
    let hasSettings = false;
    try {
      const records = app.findRecordsByFilter("costing_settings", "1=1", "", 1, 0);
      hasSettings = records && records.length > 0;
    } catch (_) {}

    if (!hasSettings) {
      const rec = new Record(settingsCol);
      rec.set("active_rate_source", "FORMULA");
      rec.set("is_rate_short_locked", true);
      rec.set("estimate_rate_column", "BASIC_RATE");
      rec.set("auto_calc_net_in_manual", true);
      rec.set("last_updated_str", "29/10/2026");
      app.save(rec);
    }
  } catch (e) {
    console.log("Migration notice for costing_settings: " + e);
  }

  // 3. Seed default costing_material_rules if empty
  try {
    const rulesCol = app.findCollectionByNameOrId("costing_material_rules");
    let hasRules = false;
    try {
      const records = app.findRecordsByFilter("costing_material_rules", "1=1", "", 1, 0);
      hasRules = records && records.length > 0;
    } catch (_) {}

    if (!hasRules) {
      const defaultRules = [
        {
          rule_name: "PET + MET PET + POLY",
          layer_type: "3_LAYER",
          printing_option: "PRINTING",
          base_category: "PET_METPET_POLY",
          extra_charge_target: "NONE",
          roll_extra_per_kg: 0.0,
          pouch_extra_per_kg: 0.0,
          override_source_mode: "USE_GLOBAL_DEFAULT",
          is_active: true
        },
        {
          rule_name: "PET + POLY (PRINTING)",
          layer_type: "2_LAYER",
          printing_option: "PRINTING",
          base_category: "PET_POLY_PRINTING",
          extra_charge_target: "NONE",
          roll_extra_per_kg: 0.0,
          pouch_extra_per_kg: 0.0,
          override_source_mode: "USE_GLOBAL_DEFAULT",
          is_active: true
        },
        {
          rule_name: "PET + POLY (PLAIN)",
          layer_type: "2_LAYER",
          printing_option: "PLAIN",
          base_category: "PET_POLY_PLAIN",
          extra_charge_target: "NONE",
          roll_extra_per_kg: 0.0,
          pouch_extra_per_kg: 0.0,
          override_source_mode: "USE_GLOBAL_DEFAULT",
          is_active: true
        },
        {
          rule_name: "WINDOW POUCH METPET (SILVER)",
          layer_type: "3_LAYER",
          printing_option: "PRINTING",
          base_category: "PET_METPET_POLY",
          extra_charge_target: "BOTH",
          roll_extra_per_kg: 10.0,
          pouch_extra_per_kg: 10.0,
          override_source_mode: "USE_GLOBAL_DEFAULT",
          is_active: true
        },
        {
          rule_name: "BOPP / MATT FINISH EXTRA",
          layer_type: "2_LAYER",
          printing_option: "PRINTING",
          base_category: "PET_POLY_PRINTING",
          extra_charge_target: "BOTH",
          roll_extra_per_kg: 5.0,
          pouch_extra_per_kg: 5.0,
          override_source_mode: "USE_GLOBAL_DEFAULT",
          is_active: true
        }
      ];

      for (const rule of defaultRules) {
        const rec = new Record(rulesCol);
        for (const k in rule) {
          rec.set(k, rule[k]);
        }
        app.save(rec);
      }
    }
  } catch (e) {
    console.log("Migration notice for costing_material_rules: " + e);
  }
}, (app) => {
  // down migration
});
