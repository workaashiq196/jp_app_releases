/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = new Collection({
    "createRule": "",
    "deleteRule": "",
    "fields": [
      {
        "autogeneratePattern": "[a-z0-9]{15}",
        "help": "",
        "hidden": false,
        "id": "text3208210256",
        "max": 15,
        "min": 15,
        "name": "id",
        "pattern": "^[a-z0-9]+$",
        "presentable": false,
        "primaryKey": true,
        "required": true,
        "system": true,
        "type": "text"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_ticket_no",
        "max": 0,
        "min": 0,
        "name": "ticket_no",
        "pattern": "",
        "presentable": true,
        "primaryKey": false,
        "required": true,
        "system": false,
        "type": "text"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_ticket_seq",
        "max": null,
        "min": null,
        "name": "ticket_seq",
        "onlyInt": true,
        "presentable": false,
        "required": true,
        "system": false,
        "type": "number"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_date",
        "max": 0,
        "min": 0,
        "name": "date",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_est_id",
        "max": 0,
        "min": 0,
        "name": "estimate_id",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_est_no",
        "max": null,
        "min": null,
        "name": "estimate_no",
        "onlyInt": true,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_client_id",
        "max": 0,
        "min": 0,
        "name": "client_id",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_client_name",
        "max": 0,
        "min": 0,
        "name": "client_name",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_item_id",
        "max": 0,
        "min": 0,
        "name": "estimate_item_id",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_matter_name",
        "max": 0,
        "min": 0,
        "name": "matter_name",
        "pattern": "",
        "presentable": true,
        "primaryKey": false,
        "required": true,
        "system": false,
        "type": "text"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_micron",
        "max": 0,
        "min": 0,
        "name": "micron",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_plain_poly",
        "max": null,
        "min": null,
        "name": "plain_polyester_wt",
        "onlyInt": false,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_ptg",
        "max": null,
        "min": null,
        "name": "ptg_wt",
        "onlyInt": false,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_silver",
        "max": null,
        "min": null,
        "name": "silver_wt",
        "onlyInt": false,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_ld",
        "max": null,
        "min": null,
        "name": "ld_wt",
        "onlyInt": false,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_lam",
        "max": null,
        "min": null,
        "name": "lamination_wt",
        "onlyInt": false,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_slit",
        "max": null,
        "min": null,
        "name": "slitting_wt",
        "onlyInt": false,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_pouch_pcs",
        "max": null,
        "min": null,
        "name": "pouch_pcs",
        "onlyInt": true,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "help": "",
        "hidden": false,
        "id": "num_wt_pouch_wt",
        "max": null,
        "min": null,
        "name": "pouch_wt",
        "onlyInt": false,
        "presentable": false,
        "required": false,
        "system": false,
        "type": "number"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_status",
        "max": 0,
        "min": 0,
        "name": "status",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_notes",
        "max": 0,
        "min": 0,
        "name": "notes",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_wt_created_by",
        "max": 0,
        "min": 0,
        "name": "created_by",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      },
      {
        "hidden": false,
        "id": "autodate_wt_created",
        "name": "created",
        "onCreate": true,
        "onUpdate": false,
        "presentable": false,
        "system": false,
        "type": "autodate"
      },
      {
        "hidden": false,
        "id": "autodate_wt_updated",
        "name": "updated",
        "onCreate": true,
        "onUpdate": true,
        "presentable": false,
        "system": false,
        "type": "autodate"
      }
    ],
    "id": "pbc_work_tickets",
    "indexes": [
      "CREATE INDEX `idx_wt_ticket_seq` ON `work_tickets` (`ticket_seq`)",
      "CREATE INDEX `idx_wt_estimate_id` ON `work_tickets` (`estimate_id`)"
    ],
    "listRule": "",
    "name": "work_tickets",
    "system": false,
    "type": "base",
    "updateRule": "",
    "viewRule": ""
  });

  app.save(collection);

  // Also add helper tracking fields to estimate_items_col
  try {
    const estItemsCol = app.findCollectionByNameOrId("estimate_items_col");
    if (estItemsCol) {
      estItemsCol.fields.addAt(estItemsCol.fields.length, new Field({
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_item_wt_id",
        "max": 0,
        "min": 0,
        "name": "work_ticket_id",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      }));
      estItemsCol.fields.addAt(estItemsCol.fields.length, new Field({
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_item_wt_no",
        "max": 0,
        "min": 0,
        "name": "work_ticket_no",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      }));
      estItemsCol.fields.addAt(estItemsCol.fields.length, new Field({
        "help": "",
        "hidden": false,
        "id": "bool_item_converted",
        "name": "is_converted",
        "presentable": false,
        "required": false,
        "system": false,
        "type": "bool"
      }));
      estItemsCol.fields.addAt(estItemsCol.fields.length, new Field({
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": "text_item_conv_date",
        "max": 0,
        "min": 0,
        "name": "converted_date",
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": "text"
      }));
      app.save(estItemsCol);
    }
  } catch (e) {
    // Graceful fallback if estimate_items_col has another name or already modified
  }
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("pbc_work_tickets");
    if (collection) {
      app.delete(collection);
    }
  } catch (e) {}
});
