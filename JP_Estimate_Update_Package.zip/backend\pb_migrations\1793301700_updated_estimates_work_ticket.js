/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  try {
    let estCol = null;
    try {
      estCol = app.findCollectionByNameOrId("estimates_col");
    } catch (e) {
      estCol = app.findCollectionByNameOrId("estimates");
    }

    if (estCol) {
      if (!estCol.fields.getByName("sent_to_work_ticket")) {
        estCol.fields.addAt(estCol.fields.length, new Field({
          "help": "Flag indicating if estimate was sent to Work Ticket Management",
          "hidden": false,
          "id": "bool_sent_to_work_ticket",
          "name": "sent_to_work_ticket",
          "presentable": false,
          "required": false,
          "system": false,
          "type": "bool"
        }));
      }

      if (!estCol.fields.getByName("sent_to_work_ticket_at")) {
        estCol.fields.addAt(estCol.fields.length, new Field({
          "autogeneratePattern": "",
          "help": "Timestamp when estimate was sent to Work Ticket",
          "hidden": false,
          "id": "text_sent_to_wt_at",
          "max": 0,
          "min": 0,
          "name": "sent_to_work_ticket_at",
          "pattern": "",
          "presentable": false,
          "primaryKey": false,
          "required": false,
          "system": false,
          "type": "text"
        }));
      }

      app.save(estCol);
    }
  } catch (err) {
    // Graceful handling
  }
}, (app) => {
  try {
    let estCol = null;
    try {
      estCol = app.findCollectionByNameOrId("estimates_col");
    } catch (e) {
      estCol = app.findCollectionByNameOrId("estimates");
    }

    if (estCol) {
      estCol.fields.removeById("bool_sent_to_work_ticket");
      estCol.fields.removeById("text_sent_to_wt_at");
      app.save(estCol);
    }
  } catch (err) {}
});
