/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  try {
    let estCol = null;
    try {
      estCol = app.findCollectionByNameOrId("estimates_col");
    } catch (e) {
      estCol = app.findCollectionByNameOrId("estimates");
    }

    if (estCol) {
      if (!estCol.fields.getByName("sent_to_work_ticket_by")) {
        estCol.fields.addAt(estCol.fields.length, new Field({
          "autogeneratePattern": "",
          "help": "User who sent this estimate to Work Ticket Management",
          "hidden": false,
          "id": "text_sent_by_user",
          "max": 0,
          "min": 0,
          "name": "sent_to_work_ticket_by",
          "pattern": "",
          "presentable": false,
          "primaryKey": false,
          "required": false,
          "system": false,
          "type": "text"
        }));
      }
      app.save(estCol);
    }
  } catch (err) {}
}, (app) => {
  try {
    let estCol = null;
    try {
      estCol = app.findCollectionByNameOrId("estimates_col");
    } catch (e) {
      estCol = app.findCollectionByNameOrId("estimates");
    }
    if (estCol) {
      estCol.fields.removeById("text_sent_by_user");
      app.save(estCol);
    }
  } catch (err) {}
});
