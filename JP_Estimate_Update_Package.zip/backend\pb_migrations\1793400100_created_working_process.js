/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  try {
    const existing = app.findCollectionByNameOrId("working_process");
    if (existing) {
      return; // Already exists, skip creation
    }
  } catch (_) {}

  const collection = new Collection({
    "id": "pbc_908154692",
    "created": "2026-11-23 09:04:52.794Z",
    "updated": "2026-11-23 09:04:52.794Z",
    "name": "working_process",
    "type": "base",
    "system": false,
    "schema": null,
    "fields": [
        {
            "autogeneratePattern": "[a-z0-9]{15}",
            "help": "",
            "hidden": false,
            "id": "text_wp_id",
            "max": 15,
            "min": 15,
            "name": "id",
            "pattern": "^[a-z0-9]+$",
            "presentable": false,
            "primaryKey": true,
            "required": true,
            "system": true,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "field_wp_date",
            "max": 0,
            "min": 0,
            "name": "date",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "field_wp_ticket_no",
            "max": 0,
            "min": 0,
            "name": "ticket_no",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "field_wp_matter_name",
            "max": 0,
            "min": 0,
            "name": "matter_name",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "field_wp_micron",
            "max": 0,
            "min": 0,
            "name": "micron",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_plain_poly",
            "max": null,
            "min": null,
            "name": "plain_polyester_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_ld_wt",
            "max": null,
            "min": null,
            "name": "ld_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_silver_wt",
            "max": null,
            "min": null,
            "name": "silver_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_plain_total",
            "max": null,
            "min": null,
            "name": "plain_total_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_ptg_wt",
            "max": null,
            "min": null,
            "name": "ptg_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_lam1",
            "max": null,
            "min": null,
            "name": "lamination_1_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_lam2",
            "max": null,
            "min": null,
            "name": "lamination_2_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_ptg_lam_total",
            "max": null,
            "min": null,
            "name": "ptg_lam_total_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_excess_wt",
            "max": null,
            "min": null,
            "name": "excess_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_slitting_wt",
            "max": null,
            "min": null,
            "name": "slitting_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_pouch_wt",
            "max": null,
            "min": null,
            "name": "pouch_wt",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "field_wp_pouch_pcs",
            "max": null,
            "min": null,
            "name": "pouch_pcs",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "field_wp_notes",
            "max": 0,
            "min": 0,
            "name": "notes",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "field_wp_operator",
            "max": 0,
            "min": 0,
            "name": "operator_name",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "hidden": false,
            "id": "autodate_wp_created",
            "name": "created",
            "onCreate": true,
            "onUpdate": false,
            "presentable": false,
            "system": false,
            "type": "autodate"
        },
        {
            "hidden": false,
            "id": "autodate_wp_updated",
            "name": "updated",
            "onCreate": true,
            "onUpdate": true,
            "presentable": false,
            "system": false,
            "type": "autodate"
        }
    ],
    "indexes": [
        "CREATE INDEX `idx_wp_ticket_no` ON `working_process` (`ticket_no`)",
        "CREATE INDEX `idx_wp_date` ON `working_process` (`date`)"
    ],
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": "",
    "options": {}
});

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("pbc_908154692");
    if (collection) {
      return app.delete(collection);
    }
  } catch (_) {}
});
