/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  try {
    const existing = app.findCollectionByNameOrId("inventory_raw_materials");
    if (existing) {
      return; // Already exists, skip creation
    }
  } catch (_) {}

  const collection = new Collection({
    "id": "pbc_3061089040",
    "created": "2026-11-23 16:01:17.252Z",
    "updated": "2026-11-23 17:06:19.897Z",
    "name": "inventory_raw_materials",
    "type": "base",
    "system": false,
    "schema": null,
    "fields": [
        {
            "autogeneratePattern": "[a-z0-9]{15}",
            "help": "",
            "hidden": false,
            "id": "text3208210256",
            "max": 15,
            "min": 15,
            "name": "id",
            "pattern": "^[a-z0-9]+$",
            "presentable": false,
            "primaryKey": true,
            "required": true,
            "system": true,
            "type": "text"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number595418541",
            "max": null,
            "min": null,
            "name": "material_code",
            "onlyInt": false,
            "presentable": false,
            "required": true,
            "system": false,
            "type": "number"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text172692275",
            "max": 0,
            "min": 0,
            "name": "material_name",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": true,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text3703245907",
            "max": 0,
            "min": 0,
            "name": "unit",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text105650625",
            "max": 0,
            "min": 0,
            "name": "category",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number3882625766",
            "max": null,
            "min": null,
            "name": "opening_stock",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number2550436364",
            "max": null,
            "min": null,
            "name": "total_inward",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number980455111",
            "max": null,
            "min": null,
            "name": "total_consumed",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number117021307",
            "max": null,
            "min": null,
            "name": "current_balance",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number2331410384",
            "max": null,
            "min": null,
            "name": "min_reorder_level",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number1395318371",
            "max": null,
            "min": null,
            "name": "unit_rate",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text2685905599",
            "max": 0,
            "min": 0,
            "name": "last_updated",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "hidden": false,
            "id": "autodate2990389176",
            "name": "created",
            "onCreate": true,
            "onUpdate": false,
            "presentable": false,
            "system": false,
            "type": "autodate"
        },
        {
            "hidden": false,
            "id": "autodate3332085495",
            "name": "updated",
            "onCreate": true,
            "onUpdate": true,
            "presentable": false,
            "system": false,
            "type": "autodate"
        },
        {
            "help": "",
            "hidden": false,
            "id": "bool458715613",
            "name": "is_active",
            "presentable": false,
            "required": false,
            "system": false,
            "type": "bool"
        }
    ],
    "indexes": [],
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": "",
    "options": {}
});

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("pbc_3061089040");
    if (collection) {
      return app.delete(collection);
    }
  } catch (_) {}
});
