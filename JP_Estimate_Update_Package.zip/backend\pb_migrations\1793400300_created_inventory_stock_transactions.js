/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  try {
    const existing = app.findCollectionByNameOrId("inventory_stock_transactions");
    if (existing) {
      return; // Already exists, skip creation
    }
  } catch (_) {}

  const collection = new Collection({
    "id": "pbc_3857758070",
    "created": "2026-11-23 16:01:17.272Z",
    "updated": "2026-11-23 16:01:17.272Z",
    "name": "inventory_stock_transactions",
    "type": "base",
    "system": false,
    "schema": null,
    "fields": [
        {
            "autogeneratePattern": "[a-z0-9]{15}",
            "help": "",
            "hidden": false,
            "id": "text3208210256",
            "max": 15,
            "min": 15,
            "name": "id",
            "pattern": "^[a-z0-9]+$",
            "presentable": false,
            "primaryKey": true,
            "required": true,
            "system": true,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text1855809928",
            "max": 0,
            "min": 0,
            "name": "transaction_type",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": true,
            "system": false,
            "type": "text"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number595418541",
            "max": null,
            "min": null,
            "name": "material_code",
            "onlyInt": false,
            "presentable": false,
            "required": true,
            "system": false,
            "type": "number"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text172692275",
            "max": 0,
            "min": 0,
            "name": "material_name",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": true,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text3399196872",
            "max": 0,
            "min": 0,
            "name": "work_ticket_no",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number2683508278",
            "max": null,
            "min": null,
            "name": "quantity",
            "onlyInt": false,
            "presentable": false,
            "required": true,
            "system": false,
            "type": "number"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number389218067",
            "max": null,
            "min": null,
            "name": "balance_after",
            "onlyInt": false,
            "presentable": false,
            "required": false,
            "system": false,
            "type": "number"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text2474346735",
            "max": 0,
            "min": 0,
            "name": "supplier_name",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text4045061810",
            "max": 0,
            "min": 0,
            "name": "invoice_no",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text18589324",
            "max": 0,
            "min": 0,
            "name": "notes",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text1286653065",
            "max": 0,
            "min": 0,
            "name": "operator_name",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text2862495610",
            "max": 0,
            "min": 0,
            "name": "date",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": true,
            "system": false,
            "type": "text"
        },
        {
            "hidden": false,
            "id": "autodate2990389176",
            "name": "created",
            "onCreate": true,
            "onUpdate": false,
            "presentable": false,
            "system": false,
            "type": "autodate"
        },
        {
            "hidden": false,
            "id": "autodate3332085495",
            "name": "updated",
            "onCreate": true,
            "onUpdate": true,
            "presentable": false,
            "system": false,
            "type": "autodate"
        }
    ],
    "indexes": [],
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": "",
    "options": {}
});

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("pbc_3857758070");
    if (collection) {
      return app.delete(collection);
    }
  } catch (_) {}
});
