/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  try {
    const existing = app.findCollectionByNameOrId("work_ticket_layer_formula");
    if (existing) {
      return; // Already exists, skip creation
    }
  } catch (_) {}

  const collection = new Collection({
    "id": "pbc_1112369079",
    "created": "2026-11-23 20:05:27.855Z",
    "updated": "2026-11-23 20:05:27.855Z",
    "name": "work_ticket_layer_formula",
    "type": "base",
    "system": false,
    "schema": null,
    "fields": [
        {
            "autogeneratePattern": "[a-z0-9]{15}",
            "help": "",
            "hidden": false,
            "id": "text3208210256",
            "max": 15,
            "min": 15,
            "name": "id",
            "pattern": "^[a-z0-9]+$",
            "presentable": false,
            "primaryKey": true,
            "required": true,
            "system": true,
            "type": "text"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text3844853612",
            "max": 0,
            "min": 0,
            "name": "micron_label",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": true,
            "system": false,
            "type": "text"
        },
        {
            "help": "",
            "hidden": false,
            "id": "number246663507",
            "max": null,
            "min": null,
            "name": "layer_count",
            "onlyInt": false,
            "presentable": false,
            "required": true,
            "system": false,
            "type": "number"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text4013493284",
            "max": 0,
            "min": 0,
            "name": "structure_name",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "help": "",
            "hidden": false,
            "id": "json2035926129",
            "maxSize": 0,
            "name": "layer_names",
            "presentable": false,
            "required": false,
            "system": false,
            "type": "json"
        },
        {
            "help": "",
            "hidden": false,
            "id": "json2317199785",
            "maxSize": 0,
            "name": "layer_ratios",
            "presentable": false,
            "required": false,
            "system": false,
            "type": "json"
        },
        {
            "autogeneratePattern": "",
            "help": "",
            "hidden": false,
            "id": "text1843675174",
            "max": 0,
            "min": 0,
            "name": "description",
            "pattern": "",
            "presentable": false,
            "primaryKey": false,
            "required": false,
            "system": false,
            "type": "text"
        },
        {
            "help": "",
            "hidden": false,
            "id": "bool4116874775",
            "name": "is_default",
            "presentable": false,
            "required": false,
            "system": false,
            "type": "bool"
        }
    ],
    "indexes": [],
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": "",
    "options": {}
});

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("pbc_1112369079");
    if (collection) {
      return app.delete(collection);
    }
  } catch (_) {}
});
