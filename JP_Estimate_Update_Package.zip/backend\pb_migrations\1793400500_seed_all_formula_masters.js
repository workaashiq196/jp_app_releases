/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const pieceFormulas = [
    {
        "micron": "12:10",
        "multiplier": 23.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:20",
        "multiplier": 21.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:30",
        "multiplier": 19.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:40",
        "multiplier": 17.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:50",
        "multiplier": 15.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:60",
        "multiplier": 13.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:70",
        "multiplier": 11.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:80",
        "multiplier": 10.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:90",
        "multiplier": 9.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:100",
        "multiplier": 8.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:110",
        "multiplier": 7.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:120",
        "multiplier": 7.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:130",
        "multiplier": 6.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:140",
        "multiplier": 6.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:150",
        "multiplier": 5.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:10",
        "multiplier": 18.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:20",
        "multiplier": 16.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:30",
        "multiplier": 14.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:40",
        "multiplier": 13.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:50",
        "multiplier": 11.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:60",
        "multiplier": 10.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:70",
        "multiplier": 9.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:80",
        "multiplier": 8.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:90",
        "multiplier": 7.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:100",
        "multiplier": 7.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:110",
        "multiplier": 6.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:120",
        "multiplier": 6.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:130",
        "multiplier": 5.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:140",
        "multiplier": 5.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:150",
        "multiplier": 4.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:10",
        "multiplier": 14.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:20",
        "multiplier": 12.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:30",
        "multiplier": 11.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:40",
        "multiplier": 10.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:50",
        "multiplier": 9.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:60",
        "multiplier": 8.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:70",
        "multiplier": 7.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:80",
        "multiplier": 6.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:90",
        "multiplier": 6.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:100",
        "multiplier": 5.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:110",
        "multiplier": 5.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:120",
        "multiplier": 4.5,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:130",
        "multiplier": 4.2,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:140",
        "multiplier": 4.0,
        "divisor": 1000000.0
    },
    {
        "micron": "12:12:12:150",
        "multiplier": 3.8,
        "divisor": 1000000.0
    }
];
  const layerFormulas = [
    {
        "micron": "12:10",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 10)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            0.5
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:0.5 (1.5 parts total)"
    },
    {
        "micron": "12:20",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 20)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:1 (2 parts total)"
    },
    {
        "micron": "12:30",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 30)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.5
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:1.5 (2.5 parts total)"
    },
    {
        "micron": "12:40",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 40)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            2.0
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:2 (3 parts total)"
    },
    {
        "micron": "12:50",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 50)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            2.5
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:2.5 (3.5 parts total)"
    },
    {
        "micron": "12:60",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 60)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            3.0
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:3 (4 parts total)"
    },
    {
        "micron": "12:70",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 70)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            3.5
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:3.5 (4.5 parts total)"
    },
    {
        "micron": "12:80",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 80)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            4.0
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:4 (5 parts total)"
    },
    {
        "micron": "12:90",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 90)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            4.5
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:4.5 (5.5 parts total)"
    },
    {
        "micron": "12:100",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 100)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            5.0
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:5 (6 parts total)"
    },
    {
        "micron": "12:110",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 110)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            5.5
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:5.5 (6.5 parts total)"
    },
    {
        "micron": "12:120",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 120)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            6.0
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:6 (7 parts total)"
    },
    {
        "micron": "12:130",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 130)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            6.5
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:6.5 (7.5 parts total)"
    },
    {
        "micron": "12:140",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 140)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            7.0
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:7 (8 parts total)"
    },
    {
        "micron": "12:150",
        "count": 2,
        "name": "2-Layer Natural (PET + LDPE 150)",
        "names": [
            "PET Film",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            7.5
        ],
        "desc": "Standard 2-Layer Natural. Ratio 1:7.5 (8.5 parts total)"
    },
    {
        "micron": "12:12:10",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 10)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            0.5
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:0.5 (2.5 parts total)"
    },
    {
        "micron": "12:12:20",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 20)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:1 (3 parts total)"
    },
    {
        "micron": "12:12:30",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 30)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            1.5
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:1.5 (3.5 parts total)"
    },
    {
        "micron": "12:12:40",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 40)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            2.0
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:2 (4 parts total)"
    },
    {
        "micron": "12:12:50",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 50)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            2.5
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:2.5 (4.5 parts total)"
    },
    {
        "micron": "12:12:60",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 60)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            3.0
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:3 (5 parts total)"
    },
    {
        "micron": "12:12:70",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 70)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            3.5
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:3.5 (5.5 parts total)"
    },
    {
        "micron": "12:12:80",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 80)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            4.0
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:4 (6 parts total)"
    },
    {
        "micron": "12:12:90",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 90)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            4.5
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:4.5 (6.5 parts total)"
    },
    {
        "micron": "12:12:100",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 100)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            5.0
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:5 (7 parts total)"
    },
    {
        "micron": "12:12:110",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 110)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            5.5
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:5.5 (7.5 parts total)"
    },
    {
        "micron": "12:12:120",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 120)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            6.0
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:6 (8 parts total)"
    },
    {
        "micron": "12:12:130",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 130)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            6.5
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:6.5 (8.5 parts total)"
    },
    {
        "micron": "12:12:140",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 140)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            7.0
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:7 (9 parts total)"
    },
    {
        "micron": "12:12:150",
        "count": 3,
        "name": "3-Layer Silver (PET + MetPET + LDPE 150)",
        "names": [
            "PET Film",
            "Silver (MetPET)",
            "LDPE Poly"
        ],
        "ratios": [
            1.0,
            1.0,
            7.5
        ],
        "desc": "Standard 3-Layer Silver. Ratio 1:1:7.5 (9.5 parts total)"
    },
    {
        "micron": "12:12:12:10",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 10)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            0.5
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:0.5 (3.5 parts total)"
    },
    {
        "micron": "12:12:12:20",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 20)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            1.0
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:1 (4 parts total)"
    },
    {
        "micron": "12:12:12:30",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 30)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            1.5
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:1.5 (4.5 parts total)"
    },
    {
        "micron": "12:12:12:40",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 40)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            2.0
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:2 (5 parts total)"
    },
    {
        "micron": "12:12:12:50",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 50)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            2.5
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:2.5 (5.5 parts total)"
    },
    {
        "micron": "12:12:12:60",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 60)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            3.0
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:3 (6 parts total)"
    },
    {
        "micron": "12:12:12:70",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 70)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            3.5
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:3.5 (6.5 parts total)"
    },
    {
        "micron": "12:12:12:80",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 80)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            4.0
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:4 (7 parts total)"
    },
    {
        "micron": "12:12:12:90",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 90)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            4.5
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:4.5 (7.5 parts total)"
    },
    {
        "micron": "12:12:12:100",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 100)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            5.0
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:5 (8 parts total)"
    },
    {
        "micron": "12:12:12:110",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 110)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            5.5
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:5.5 (8.5 parts total)"
    },
    {
        "micron": "12:12:12:120",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 120)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            6.0
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:6 (9 parts total)"
    },
    {
        "micron": "12:12:12:130",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 130)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            6.5
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:6.5 (9.5 parts total)"
    },
    {
        "micron": "12:12:12:140",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 140)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            7.0
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:7 (10 parts total)"
    },
    {
        "micron": "12:12:12:150",
        "count": 4,
        "name": "4-Layer Barrier (PET + Met/Foil + Nylon + LDPE 150)",
        "names": [
            "PET Print",
            "Foil / MetPET",
            "Nylon / Bon",
            "LDPE Sealant"
        ],
        "ratios": [
            1.0,
            1.0,
            1.0,
            7.5
        ],
        "desc": "High Barrier 4-Layer. Ratio 1:1:1:7.5 (10.5 parts total)"
    }
];

  // 1. Seed formula_master
  try {
    const fmCol = app.findCollectionByNameOrId("formula_master");
    for (const f of pieceFormulas) {
      try {
        const existing = app.findFirstRecordByFilter("formula_master", "micron_label = {:ml}", { ml: f.micron });
        if (!existing) {
          const rec = new Record(fmCol);
          rec.set("micron_label", f.micron);
          rec.set("multiplier", f.multiplier);
          rec.set("divisor_factor", f.divisor);
          app.save(rec);
        }
      } catch (_) {
        const rec = new Record(fmCol);
        rec.set("micron_label", f.micron);
        rec.set("multiplier", f.multiplier);
        rec.set("divisor_factor", f.divisor);
        app.save(rec);
      }
    }
  } catch (e) {
    console.log("Migration notice for formula_master: " + e);
  }

  // 2. Seed work_ticket_layer_formula
  try {
    const wtCol = app.findCollectionByNameOrId("work_ticket_layer_formula");
    for (const l of layerFormulas) {
      try {
        const existing = app.findFirstRecordByFilter("work_ticket_layer_formula", "micron_label = {:ml}", { ml: l.micron });
        if (!existing) {
          const rec = new Record(wtCol);
          rec.set("micron_label", l.micron);
          rec.set("layer_count", l.count);
          rec.set("structure_name", l.name);
          rec.set("layer_names", l.names);
          rec.set("layer_ratios", l.ratios);
          rec.set("description", l.desc);
          rec.set("is_default", true);
          app.save(rec);
        }
      } catch (_) {
        const rec = new Record(wtCol);
        rec.set("micron_label", l.micron);
        rec.set("layer_count", l.count);
        rec.set("structure_name", l.name);
        rec.set("layer_names", l.names);
        rec.set("layer_ratios", l.ratios);
        rec.set("description", l.desc);
        rec.set("is_default", true);
        app.save(rec);
      }
    }
  } catch (e) {
    console.log("Migration notice for work_ticket_layer_formula: " + e);
  }
}, (app) => {
  // Down migration
});
