/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_work_tickets") || app.findCollectionByNameOrId("work_tickets");
  if (!collection) return;

  if (!collection.fields.getByName("ups")) {
    collection.fields.addAt(collection.fields.length, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text_wt_ups",
      "max": 0,
      "min": 0,
      "name": "ups",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }));
  }

  if (!collection.fields.getByName("cylinder_colors")) {
    collection.fields.addAt(collection.fields.length, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text_wt_cylinder_colors",
      "max": 0,
      "min": 0,
      "name": "cylinder_colors",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }));
  }

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_work_tickets") || app.findCollectionByNameOrId("work_tickets");
  if (!collection) return;

  const f1 = collection.fields.getByName("ups");
  if (f1) collection.fields.removeById(f1.id);

  const f2 = collection.fields.getByName("cylinder_colors");
  if (f2) collection.fields.removeById(f2.id);

  return app.save(collection);
});
