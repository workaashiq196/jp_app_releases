/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_work_tickets")

  // add field
  if (!collection.fields.getByName("ups")) {
    collection.fields.addAt(58, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text1263020761",
      "max": 0,
      "min": 0,
      "name": "ups",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  // add field
  if (!collection.fields.getByName("cylinder_colors")) {
    collection.fields.addAt(59, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text1708516628",
      "max": 0,
      "min": 0,
      "name": "cylinder_colors",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }))
  }

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_work_tickets")

  // remove field
  collection.fields.removeById("text1263020761")

  // remove field
  collection.fields.removeById("text1708516628")

  return app.save(collection)
})
