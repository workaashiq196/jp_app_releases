/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("work_tickets") || app.findCollectionByNameOrId("pbc_work_tickets");
  if (!collection) return;

  // add field
  if (!collection.fields.getByName("ups")) {
    collection.fields.addAt(collection.fields.length, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text1263020761",
      "max": 0,
      "min": 0,
      "name": "ups",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }));
  }

  // add field
  if (!collection.fields.getByName("cylinder_colors")) {
    collection.fields.addAt(collection.fields.length, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text1708516628",
      "max": 0,
      "min": 0,
      "name": "cylinder_colors",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }));
  }

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("work_tickets") || app.findCollectionByNameOrId("pbc_work_tickets");
  if (!collection) return;

  // remove field
  try {
    collection.fields.removeById("text1263020761");
  } catch (_) {}

  // remove field
  try {
    collection.fields.removeById("text1708516628");
  } catch (_) {}

  return app.save(collection);
});
