/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("work_tickets") || app.findCollectionByNameOrId("pbc_work_tickets");
  if (!collection) return;

  // add field
  if (!collection.fields.getByName("printing_machine")) {
    collection.fields.addAt(collection.fields.length, new Field({
      "autogeneratePattern": "",
      "help": "",
      "hidden": false,
      "id": "text3020889854",
      "max": 0,
      "min": 0,
      "name": "printing_machine",
      "pattern": "",
      "presentable": false,
      "primaryKey": false,
      "required": false,
      "system": false,
      "type": "text"
    }));
  }

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("work_tickets") || app.findCollectionByNameOrId("pbc_work_tickets");
  if (!collection) return;

  // remove field
  try {
    collection.fields.removeById("text3020889854");
  } catch (_) {}

  return app.save(collection);
});
