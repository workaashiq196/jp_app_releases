/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("working_process") || app.findCollectionByNameOrId("pbc_908154692");
  if (!collection) return;

  const fieldsToAdd = [
    { id: "text3020889854", name: "printing_machine", type: "text" },
    { id: "number3792498125", name: "plain_poly_core_wt", type: "number" },
    { id: "number960025018", name: "ld_core_wt", type: "number" },
    { id: "number207695659", name: "silver_core_wt", type: "number" },
    { id: "number1122215690", name: "ptg_core_wt", type: "number" },
    { id: "number3395451093", name: "lam1_core_wt", type: "number" },
    { id: "number4092544016", name: "lam2_core_wt", type: "number" },
    { id: "number2919727552", name: "slitting_core_wt", type: "number" },
    { id: "text3028536996", name: "film_size_mm", type: "text" },
  ];

  for (const f of fieldsToAdd) {
    if (!collection.fields.getByName(f.name)) {
      collection.fields.addAt(collection.fields.length, new Field({
        "autogeneratePattern": "",
        "help": "",
        "hidden": false,
        "id": f.id,
        "max": f.type === "number" ? null : 0,
        "min": f.type === "number" ? null : 0,
        "name": f.name,
        "onlyInt": false,
        "pattern": "",
        "presentable": false,
        "primaryKey": false,
        "required": false,
        "system": false,
        "type": f.type
      }));
    }
  }

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("working_process") || app.findCollectionByNameOrId("pbc_908154692");
  if (!collection) return;

  const fieldIds = [
    "text3020889854", "number3792498125", "number960025018", "number207695659",
    "number1122215690", "number3395451093", "number4092544016", "number2919727552", "text3028536996"
  ];

  for (const id of fieldIds) {
    try {
      collection.fields.removeById(id);
    } catch (_) {}
  }

  return app.save(collection);
});
