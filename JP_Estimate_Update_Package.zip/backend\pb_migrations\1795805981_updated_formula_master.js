/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("formula_master_col")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_fm_micron` ON `formula_master` (`micron_label`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("formula_master_col")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
