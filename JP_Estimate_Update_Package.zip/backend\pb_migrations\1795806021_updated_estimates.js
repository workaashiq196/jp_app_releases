/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_estimates_estimate_no` ON `estimates` (`estimate_no`)",
      "CREATE INDEX `idx_estimates_client_id` ON `estimates` (`client_id`)",
      "CREATE INDEX `idx_estimates_date` ON `estimates` (`date`)",
      "CREATE INDEX `idx_estimates_status` ON `estimates` (`status`)",
      "CREATE INDEX `idx_estimates_created` ON `estimates` (`created`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimates_col")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
