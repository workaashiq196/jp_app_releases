/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("clients_col")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_clients_name` ON `clients` (`name`)",
      "CREATE INDEX `idx_clients_phone` ON `clients` (`phone`)",
      "CREATE INDEX `idx_clients_gst` ON `clients` (`gst_number`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("clients_col")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
