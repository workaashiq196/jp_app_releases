/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("estimate_items_col")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_ei_estimate_id` ON `estimate_items` (`estimate_id`)",
      "CREATE INDEX `idx_ei_work_ticket_id` ON `estimate_items` (`work_ticket_id`)",
      "CREATE INDEX `idx_ei_work_ticket_no` ON `estimate_items` (`work_ticket_no`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("estimate_items_col")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
