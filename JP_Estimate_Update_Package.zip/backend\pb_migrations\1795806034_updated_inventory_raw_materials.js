/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3061089040")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_irm_code` ON `inventory_raw_materials` (`material_code`)",
      "CREATE INDEX `idx_irm_name` ON `inventory_raw_materials` (`material_name`)",
      "CREATE INDEX `idx_irm_category` ON `inventory_raw_materials` (`category`)",
      "CREATE INDEX `idx_irm_active` ON `inventory_raw_materials` (`is_active`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3061089040")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
