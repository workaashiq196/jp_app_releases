/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3857758070")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_ist_material_code` ON `inventory_stock_transactions` (`material_code`)",
      "CREATE INDEX `idx_ist_work_ticket_no` ON `inventory_stock_transactions` (`work_ticket_no`)",
      "CREATE INDEX `idx_ist_date` ON `inventory_stock_transactions` (`date`)",
      "CREATE INDEX `idx_ist_type` ON `inventory_stock_transactions` (`transaction_type`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3857758070")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
