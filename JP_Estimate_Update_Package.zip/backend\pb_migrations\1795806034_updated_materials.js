/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_4282183725")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_materials_name` ON `materials` (`name`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_4282183725")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
