/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1829178101")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_raw_mtlcde` ON `raw_materials` (`mtlcde`)",
      "CREATE INDEX `idx_raw_mtlnme` ON `raw_materials` (`mtlnme`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1829178101")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
