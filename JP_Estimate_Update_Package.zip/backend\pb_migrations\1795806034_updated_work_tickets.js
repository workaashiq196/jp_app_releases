/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_work_tickets")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_wt_ticket_seq` ON `work_tickets` (`ticket_seq`)",
      "CREATE INDEX `idx_wt_estimate_id` ON `work_tickets` (`estimate_id`)",
      "CREATE INDEX `idx_wt_ticket_no` ON `work_tickets` (`ticket_no`)",
      "CREATE INDEX `idx_wt_client_id` ON `work_tickets` (`client_id`)",
      "CREATE INDEX `idx_wt_date` ON `work_tickets` (`date`)",
      "CREATE INDEX `idx_wt_status` ON `work_tickets` (`status`)",
      "CREATE INDEX `idx_wt_prod_status` ON `work_tickets` (`production_status`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_work_tickets")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_wt_ticket_seq` ON `work_tickets` (`ticket_seq`)",
      "CREATE INDEX `idx_wt_estimate_id` ON `work_tickets` (`estimate_id`)"
    ]
  }, collection)

  return app.save(collection)
})
