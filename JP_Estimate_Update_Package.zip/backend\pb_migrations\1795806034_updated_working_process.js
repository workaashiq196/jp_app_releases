/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_908154692")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_wp_ticket_no` ON `working_process` (`ticket_no`)",
      "CREATE INDEX `idx_wp_date` ON `working_process` (`date`)",
      "CREATE INDEX `idx_wp_operator_name` ON `working_process` (`operator_name`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_908154692")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_wp_ticket_no` ON `working_process` (`ticket_no`)",
      "CREATE INDEX `idx_wp_date` ON `working_process` (`date`)"
    ]
  }, collection)

  return app.save(collection)
})
