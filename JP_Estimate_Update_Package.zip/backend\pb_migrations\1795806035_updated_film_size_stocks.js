/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_2286714434")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE INDEX `idx_fss_material_size` ON `film_size_stocks` (`material_code`, `size_mm`)"
    ]
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_2286714434")

  // update collection data
  unmarshal({
    "indexes": []
  }, collection)

  return app.save(collection)
})
